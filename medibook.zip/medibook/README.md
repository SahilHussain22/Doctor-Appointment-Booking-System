# MediBook — Online Doctor Appointment Booking System

A PHP + MySQL mini-project for a BSc Computer Science project. It uses **exactly three roles**: Patient, Doctor and Admin. Doctor accounts are created and approved only by Admin.

## Requirements
- Windows with XAMPP (Apache and MySQL)
- PHP 8.0+ recommended; MySQL/MariaDB supported by XAMPP
- Visual Studio Code (optional)

## Install on XAMPP
1. Install and open XAMPP Control Panel.
2. Start **Apache** and **MySQL**.
3. Copy the `medibook` folder into `C:\xampp\htdocs\medibook`.
4. Open `http://localhost/phpmyadmin/`.
5. Choose **Import**, select `medibook/database/medibook.sql`, and run the import. The SQL creates the `medibook` database and tables.
6. Open `config/database.php`. Default XAMPP settings are host `127.0.0.1`, user `root`, blank password. Adjust these if your MySQL credentials differ.
7. Visit `http://localhost/medibook/setup/create-admin.php` and create your own admin account with a strong password (12+ characters).
8. **Immediately delete `setup/create-admin.php` after successful setup.** The page also blocks a second setup once an admin exists, but removing it is safer.
9. Open `http://localhost/medibook/`.

## First test walkthrough
1. Register a patient at `/register.php`, then sign in at `/login.php`.
2. Sign in as Admin at `/admin/login.php` using the account created in setup.
3. Use **Add doctor** to create a doctor account. Choose “Approve and activate” if you want it available immediately. Keep the temporary password private.
4. Log out and sign in at `/doctor/login.php` with the doctor credentials.
5. Open **Availability** and add a future date/time range. The system creates individual slots of the selected duration.
6. Log out, sign in as Patient, find the doctor, open the profile and request an appointment for one of the published slots.
7. Log in as Doctor, open **Appointments**, and approve or reject the pending request. Approved visits can be marked Completed.
8. Log back in as Patient to confirm the updated status. Admin can inspect all appointments and activity logs.

## Project structure
- `index.php`, `doctors.php`, `doctor-details.php`: public pages
- `register.php`, `login.php`, `logout.php`: patient auth and logout
- `patient/`: patient dashboard, booking, appointments and profile
- `doctor/`: separate doctor login, dashboard, appointments, availability and profile
- `admin/`: separate admin login, system management and doctor profile editing
- `config/database.php`: PDO connection
- `includes/`: shared auth, CSRF, output escaping, layout and helpers
- `assets/`: responsive CSS and JavaScript
- `database/medibook.sql`: schema and specialization seed data
- `setup/create-admin.php`: one-time admin creation; remove after use

## Important rules and security notes
- Passwords are stored with `password_hash()` and checked with `password_verify()`.
- SQL queries use PDO prepared statements.
- Login regenerates the session ID; logout clears the session.
- Protected pages check the role on the server. Patients can see only their own appointments; doctors query only their own assigned appointments.
- Mutating POST forms include CSRF tokens. Output is escaped with `htmlspecialchars()`.
- Patient self-registration always creates a Patient. It cannot accept a public role field.
- Admin can create, approve, activate and deactivate doctors. Deactivated users cannot pass the role guard.
- Appointment requests are created as Pending. Doctors may approve/reject Pending requests and complete Approved appointments. Patients may cancel only their own future Pending requests.
- Booking checks the doctor availability slot and active booking state inside a transaction. The unique availability key prevents duplicate slot definitions; the transaction and active-status check reduce duplicate booking races.
- A Pending or Approved appointment reserves the slot. Rejected/Cancelled appointments release it. Completed appointments remain historical records and are not treated as active reservations.
- Availability disabling is blocked while a Pending or Approved appointment references the slot.

## Troubleshooting
- **Database connection failed:** check MySQL is running and verify `config/database.php` credentials.
- **404 Not Found:** make sure the folder is named `medibook` and lives inside XAMPP's `htdocs`; URLs assume `/medibook/`.
- **Apache/MySQL will not start:** another service may be using ports 80/443 or 3306. Review XAMPP logs and resolve the port conflict.
- **No doctors shown:** create a doctor through Admin and approve/activate the account, then add future availability through the Doctor dashboard.
- **Booking says slot unavailable:** the slot may be disabled, in the past, or already requested. Choose another published slot.
- **CSRF form expired:** refresh the page and submit again.
- **Admin setup says already complete:** use the existing admin login; delete the setup script.

## Scope and limitations
This is a local educational demonstration, not a production healthcare service. No email/SMS delivery, payment gateway, medical records, profile-photo upload, or external API is included. Notifications are provided as on-screen status updates through the dashboards. Use synthetic data only. For production, add HTTPS, rate limiting, stronger audit review, backups, privacy/legal review and more extensive automated testing. MySQL `CHECK` enforcement varies by server version.

## Viva talking points
- Three-role role-based access control
- Relational schema and foreign keys
- Prepared statements and password hashing
- CSRF protection and output escaping
- Appointment state transitions
- Transaction-based slot booking and duplicate prevention
- Responsive frontend using plain HTML, CSS and JavaScript
