CREATE DATABASE IF NOT EXISTS medibook CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE medibook;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS activity_logs, notifications, appointments, doctor_availability, doctor_profiles, patient_profiles, specializations, users;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(30) NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('patient','doctor','admin') NOT NULL,
 account_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_users_role_status(role,account_status), INDEX idx_users_name(full_name)
) ENGINE=InnoDB;
CREATE TABLE patient_profiles (
 patient_id BIGINT UNSIGNED PRIMARY KEY,
 gender ENUM('Female','Male','Other') NULL,
 date_of_birth DATE NULL,
 FOREIGN KEY(patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE specializations (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 specialization_name VARCHAR(100) NOT NULL UNIQUE,
 description VARCHAR(255) NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE doctor_profiles (
 doctor_id BIGINT UNSIGNED PRIMARY KEY,
 specialization_id INT UNSIGNED NOT NULL,
 qualification VARCHAR(150) NOT NULL,
 experience_years TINYINT UNSIGNED NOT NULL DEFAULT 0,
 consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 clinic_address VARCHAR(255) NULL,
 profile_photo VARCHAR(255) NULL,
 available_days VARCHAR(255) NULL,
 is_approved TINYINT(1) NOT NULL DEFAULT 0,
 FOREIGN KEY(doctor_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(specialization_id) REFERENCES specializations(id), INDEX idx_doctor_specialization(specialization_id,is_approved)
) ENGINE=InnoDB;
CREATE TABLE doctor_availability (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 doctor_id BIGINT UNSIGNED NOT NULL,
 available_date DATE NOT NULL,
 start_time TIME NOT NULL,
 end_time TIME NOT NULL,
 slot_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 30,
 is_available TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_doctor_slot(doctor_id,available_date,start_time),
 FOREIGN KEY(doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE CASCADE,
 INDEX idx_availability_search(available_date,is_available), CHECK(end_time>start_time)
) ENGINE=InnoDB;
CREATE TABLE appointments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 patient_id BIGINT UNSIGNED NOT NULL,
 doctor_id BIGINT UNSIGNED NOT NULL,
 availability_id BIGINT UNSIGNED NOT NULL,
 appointment_date DATE NOT NULL,
 start_time TIME NOT NULL,
 end_time TIME NOT NULL,
 consultation_reason VARCHAR(1000) NOT NULL,
 status ENUM('Pending','Approved','Rejected','Cancelled','Completed') NOT NULL DEFAULT 'Pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES users(id),
 FOREIGN KEY(doctor_id) REFERENCES doctor_profiles(doctor_id),
 FOREIGN KEY(availability_id) REFERENCES doctor_availability(id),
 INDEX idx_patient_appointments(patient_id,appointment_date,status),
 INDEX idx_doctor_appointments(doctor_id,appointment_date,status),
 INDEX idx_appointment_status(status),
 CHECK(end_time>start_time)
) ENGINE=InnoDB;
CREATE TABLE notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL,
 message VARCHAR(500) NOT NULL,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_notifications_user(user_id,is_read,created_at)
) ENGINE=InnoDB;
CREATE TABLE activity_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL,
 details VARCHAR(500) NULL,
 ip_address VARCHAR(45) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_activity_created(created_at)
) ENGINE=InnoDB;
INSERT INTO specializations(specialization_name,description) VALUES
('Cardiology','Heart and cardiovascular care'),('Dermatology','Skin, hair and nail care'),('Neurology','Brain and nervous system care'),('Pediatrics','Healthcare for children'),('Orthopedics','Bones, joints and muscles'),('Dentistry','Oral and dental care'),('Ophthalmology','Eye and vision care'),('General Medicine','Primary and general healthcare');
-- Admin is created securely using setup/create-admin.php; no plaintext admin password is included.
-- Doctor accounts are created from the Admin dashboard. Add availability from the Doctor dashboard.
